clear all
close all

N = 100; % Number of processes
T = 10^3; % Length of time series

flag = 'G'; % G for Gaussian random walk, L for L�vy stable process

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Random walk %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if flag == 'G'

    x = randn(N,T); % Generating time series

    q = linspace(0.1,2,40); % Grid of values of q

    H = []; % Empty vector to store values of Generalized Hurst Exponent

    %%% Loop on time series: for each individual time series the
    %%% Generalized Hurst Exponent is computed for each value of q

    for n = 1:N
        
        %%% The function used here returns the Generalized Hurst Exponent
        %%% for all values in the vector q
        tmp = genhurst(cumsum(x(n,:)),q);

        H = [H; tmp'];

    end

    %%% Plotting the Generalized Hurst Exponent against the expected
    %%% behaviour (qH(q) = q/2 for a Gaussian random walk)
    
    aux = q.*H;
    
    plot(q,q/2,'r','LineWidth',2)
    hold on
    
    errorbar(q,mean(aux),mean(aux)-quantile(aux,0.025),quantile(aux,0.975)-mean(aux),'ob','MarkerSize',8)
    
    xlabel('$q$','Interpreter','LaTex')
    ylabel('$qH(q)$','Interpreter','LaTex')
    set(gca,'FontSize',20)    

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Levy stable distributions %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

elseif flag == 'L'

    alpha = 0.8; % Tail parameter
    beta = 0; % Skewness parameter
    gamma = 1; % Scale parameter  
    delta = 0; % Location parameter

    x = random('Stable',alpha,beta,gamma,delta,[N T]); % Generating time series
    
    % Grid of values of q
    if alpha < 1
        q = linspace(0.1,2,40);
    elseif alpha >= 1
        q = linspace(0.1,3,40);
    end

    H = []; % Empty vector to store values of Generalized Hurst Exponent

   %%% Loop on time series: for each individual time series the
    %%% Generalized Hurst Exponent is computed for each value of q

    for n = 1:N

        %%% The function used here returns the Generalized Hurst Exponent
        %%% for all values in the vector q
        tmp = genhurst(cumsum(x(n,:)),q);

        H = [H; tmp'];

    end

    %%% Plotting the Generalized Hurst Exponent against the expected
    %%% behaviour (see slides for different behaviours depending on alpha)
    
    if alpha < 1 
        x = linspace(0,1,200);
        plot(x,x,'r','LineWidth',2)
        hold on
        x = linspace(1,2,200);
        plot(x,ones(1,200),'r','LineWidth',2)
        hold on
    elseif alpha >= 1
        x = linspace(0,alpha,200);
        plot(x,x/alpha,'r','LineWidth',2)
        hold on
        x = linspace(alpha,3,200);
        plot(x,ones(1,200),'r','LineWidth',2)
        hold on    
    end

    aux = q.*H;

    errorbar(q,mean(aux),mean(aux)-quantile(aux,0.025),quantile(aux,0.975)-mean(aux),'ob','MarkerSize',8)

    xlabel('$q$','Interpreter','LaTex')
    ylabel('$qH(q)$','Interpreter','LaTex')
    set(gca,'FontSize',20)

end
