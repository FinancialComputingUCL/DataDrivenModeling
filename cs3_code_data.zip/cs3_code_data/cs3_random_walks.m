clear all
close all

flag = 'G'; % G for Gaussian, L for L�vy

T = 500; % Length of random walks
N = 50000; % Number of random walks to be generated

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Gaussian random walk %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

if flag == 'G'

    subplot(2,2,1)

    sigma = 1; % Standard deviation of increments

    X = sigma*cumsum(randn(T,N)); % Building random walk time series

    plot([1:1:T],X(:,1:500)) % Plotting sample of trajectories
    xlim([1 T])
    xlabel('$t$','Interpreter','LaTex')
    ylabel('$x(t)$','Interpreter','LaTex')
    set(gca,'FontSize',18)
    
    %%% Plotting scaling of standard deviation
    
    subplot(2,2,2)
   
    t = [1:1:T];
    plot(t,sigma*sqrt(t),'-b','LineWidth',1) % Plotting expected scaling of variance
    hold on
   
    t = 1:50:T; % Time steps at which empirical variance is computer
    plot(t,std(X(t,:)'),'o','MarkerSize',8,'MarkerFaceColor','r') % Plotting empirical scaling of variance at selected time steps
    xlim([1 500])    
    xlabel('$t$','Interpreter','LaTex')
    ylabel('$\sigma \sqrt{t}$','Interpreter','LaTex')
    set(gca,'FontSize',18)   
    
    %%% Plotting distributions at two different times

    subplot(2,2,3)
    
    t1 = T/5; % First selected time
    t2 = T; % Second selected time

    h1 = histogram(X(t1,:),50,'Normalization','PDF') % Histogram at time t1
    x1 = h1.BinEdges(1:end-1)/sqrt(t1); % Rescaling histogram for later use
    y1 = h1.Values*sqrt(t1); % Rescaling histogram for later use    
    hold on
    
    h2 = histogram(X(t2,:),50,'Normalization','PDF') % Histogram at time t1
    x2 = h2.BinEdges(1:end-1)/sqrt(t2); % Rescaling histogram for later use
    y2 = h2.Values*sqrt(t2); % Rescaling histogram for later use
    hold on
    
    sigma_res1 = sigma*sqrt(t1); % Rescaled standard deviation at time T/5
    x = linspace(-5*sigma_res1,5*sigma_res1,1000);
    y = exp(-x.^2/(2*sigma_res1^2))/sqrt(2*pi*sigma_res1^2);
    plot(x,y,'b','LineWidth',2)

    sigma_res2 = sigma*sqrt(t2); % Rescaled standard deviation at time T
    x = linspace(-5*sigma_res2,5*sigma_res2,1000);
    y = exp(-x.^2/(2*sigma_res2^2))/sqrt(2*pi*sigma_res2^2);
    plot(x,y,'r','LineWidth',2)
        
    xlim([-5*max(sigma_res1,sigma_res2) 5*max(sigma_res1,sigma_res2)])
    xlabel('$x$','Interpreter','LaTex')
    ylabel('$p(x)$','Interpreter','LaTex')
    set(gca,'FontSize',18)   
    
    %%% Plotting rescaled histograms vs standard Gaussian (in log scale)

    subplot(2,2,4)

    x = linspace(-5,5,1000);
    y = exp(-x.^2/2)/sqrt(2*pi);
    plot(x,y,'m','LineWidth',2)  
    hold on
    
    plot(x1,y1,'ob','MarkerSize',8,'MarkerFaceColor','blue')
    hold on
    plot(x2,y2,'xr','MarkerSize',8,'LIneWidth',2)
    hold on
    xlabel('$x$','Interpreter','LaTex')
    ylabel('$p(x)$','Interpreter','LaTex')
    set(gca,'YScale','log','FontSize',18)
    
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% L�vy walk %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

elseif flag == 'L'
    
    subplot(1,3,1)
    
    alpha = 0.8; % Tail parameter
    beta = 0; % Skewness parameter
    c = 1; % Scale parameter  
    mu = 0; % Location parameter

    X = cumsum(random('Stable',alpha,beta,c,mu,[T N])); % Building random L�vy walk time series
    
    plot([1:1:T],X(:,1:500)) % Plotting sample of trajectories
    xlim([1 T])
    xlabel('$t$','Interpreter','LaTex')
    ylabel('$x(t)$','Interpreter','LaTex')
    set(gca,'FontSize',18)
    
    %%% Plotting distributions at two different times
    
    subplot(1,3,2)
    
    t1 = T/5; % First selected time
    t2 = T; % Second selected time    
    
    h1 = histogram(X(t1,:),50,'Normalization','PDF') % Histogram at time t1
    x1 = h1.BinEdges(1:end-1)/(t1)^(1/alpha); % Rescaling histogram for later use
    y1 = h1.Values*(t1)^(1/alpha); % Rescaling histogram for later use          
    hold on   
    
    h2 = histogram(X(t2,:),50,'Normalization','PDF') % Histogram at time t2
    x2 = h2.BinEdges(1:end-1)/(t2)^(1/alpha); % Rescaling histogram for later use
    y2 = h2.Values*(t2)^(1/alpha); % Rescaling histogram for later use            
    hold on
    
    pd = makedist('Stable','alpha',alpha,'beta',beta,'gam',c,'delta',mu);
    
    x = linspace(-max(abs(X(t1,:))),max(abs(X(t1,:))),1000);
    y = pdf(pd,x/(t1)^(1/alpha))/(t1)^(1/alpha);
    plot(x,y,'b','LineWidth',2);
    hold on
    
    x = linspace(-max(abs(X(t2,:))),max(abs(X(t2,:))),1000);
    y = pdf(pd,x/(t2)^(1/alpha))/(t2)^(1/alpha);
    plot(x,y,'r','LineWidth',2);   
    xlabel('$x$','Interpreter','LaTex')
    ylabel('$p(x)$','Interpreter','LaTex')
    set(gca,'YScale','log','FontSize',18)
    
    subplot(1,3,3)
    
    x = linspace(-max(abs(x1))*1.05,max(abs(x1))*1.05,1000);
    y = pdf(pd,x);
    plot(x,y,'b','LineWidth',2);
    hold on
    
    plot(x1,y1,'ob','MarkerSize',8,'MarkerFaceColor','blue')
    hold on
    plot(x2,y2,'xr','MarkerSize',8,'LIneWidth',2)
    hold on
    xlabel('$x$','Interpreter','LaTex')
    ylabel('$p(x)$','Interpreter','LaTex')
    set(gca,'YScale','log','FontSize',18)
    
end

