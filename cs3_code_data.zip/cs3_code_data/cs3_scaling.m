clear all
close all

%%% This code produces a plot to showcase the scaling behaviour over time
%%% of cryptocurrenty returns (in terms of Generalized Hurst Exponent) and
%%% then assesses whether such behaviour is statistically significant or 
%%% not by comparing the results obtained with the empirical time series
%%% against those obtained with randomly reshuffled time series.

b = load('cryptocurrency_prices.txt');

q = linspace(0.1,6,20); % Grid of values of q

plot(q,0.5*q,'k','Linewidth',2) % Plotting expected behaviour for Gaussian random walk
hold on

for i = 1:size(b,1)

    r = log(b(i,2:end)./b(i,1:end-1)); % Log-returns of i-th cryptocurrency
     
    %%% The function used here returns the Generalized Hurst Exponent
    %%% for all values in the vector q
    H = genhurst(cumsum(r),q);

    plot(q,q.*H','o-','MarkerSize',8,'LineWidth',2)
    hold on

end

legend({'BM','Bitcoin','Dash','Ethereum','Litecoin','Monero','Nem','Ripple'},'Location','northwest')
xlabel('$q$','Interpreter','LaTex')
ylabel('$qH(q)$','Interpreter','LaTex')
set(gca,'FontSize',20)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Testing with random permutation test %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(2)

nmods = 100; % Number of reshuffled time series to be generated for each
             % cryptocurrency

titles = {'Bitcoin','Dash','Ethereum','Litecoin','Monero','Nem','Ripple'};

for i = 1:7
    
    r = log(b(i,2:end)./b(i,1:end-1));
    
    subplot(2,4,i)
   
    plot(q,0.5*q,'k','Linewidth',2)
    hold on
        
    H_aux = []; % Empty vector to collect Hurst Exponent values for all reshuffled time  series
    
    for nm = 1:nmods
        
        aux = r(randperm(length(r))); % Reshuffling returns
    
        H_aux = [H_aux; genhurst(cumsum(aux),q)']; % Computing Generalized Hurst Exponent for reshuffled time series
        
    end
    
    aux = q.*H_aux;
    
    errorbar(q,mean(aux),mean(aux)-quantile(aux,0.025),quantile(aux,0.975)-mean(aux),'ob','Linewidth',1.5,'Markersize',4)
    hold on
    
    H = genhurst(cumsum(r),q);

    plot(q,q.*H','o-m','Linewidth',2,'Markersize',8)
    xlabel('$q$','Interpreter','LaTex')
    ylabel('$qH(q)$','Interpreter','LaTex')
    title(titles{i})
    set(gca,'FontSize',15)
    
end

