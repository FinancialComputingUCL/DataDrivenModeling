
clear all
close all

%%% The file loaded here is a 7x929 matrix where each row corresponds to
%%% 929 daily returns of a different cryptocurrency, ending in February
%%% 2018

P = load('cryptocurrency_prices.txt');

%%% Row 1: Bitcoin
%%% Row 2: Dash
%%% Row 3: Ethereum
%%% Row 4: Litecoin
%%% Row 5: Monero
%%% Row 6: Nem
%%% Row 7: Ripple
 
%%% Building log-returns 
 
R = [];

for i = 1:size(P,1)
    R = [R; log(P(i,2:end)./P(i,1:end-1))];
end

N = size(R,1); % Number of variables
T = size(R,2); % Depth of time series

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Building correlation matrix %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Standardizing data by subtracting mean and dividing by std. dev.

X = [];

for i = 1:N
   X = [X; (R(i,:) - mean(R(i,:)))/std(R(i,:))];
end

C = corr(R'); %%% Correlation matrix 

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Testing statistical significance of correlations %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

Nsamples = 500; % Number of times correlation between reshuffled returns
                % are computed for each pair of currencies
                
x = []; g = []; coeff = [];
c = 1;

for i = 1:N
   for j = i+1:N
      
       aux = [];
       
       for ns = 1:Nsamples
          
           %%% Computing correlation on randomly reshuffled returns
           aux = [aux; sum(X(i,randperm(T)).*X(j,randperm(T)))/T];
           
       end
       
       x = [x; aux];
       g = [g; repmat(c,length(aux),1)];
       coeff = [coeff; C(i,j)];
       c = c+1;
                     
   end
end

boxplot(x,g,'OutlierSize',4)
hold on
plot(1:1:N*(N-1)/2,coeff,'db','MarkerSize',8,'MarkerFaceColor','blue')
ylim([-0.1 0.55])
ylabel('$\mathrm{Correlations}$','Interpreter','Latex')
set(gca,'FontSize',20)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Principal component analysis (PCA) %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Eigenvalues and eigenvectors: in the commands below L is a diagonal
%%% matrix with the eigenvalues of C on the main diagonal, which are then
%%% extracted as a vector with the command diag. V is the NxN matrix of the
%%% eigenvectors: its n-th column is the eigenvector of the n-th eigenvalue

[V,L] = eig(C); 
[L,ind] = sort(diag(L),'descend');
V = V(:,ind);

fprintf('\n')

for i = 1:N
    
    fprintf('Eigevalue %d = %4.3f (%4.3f per cent of variance explained)\n',i,L(i),L(i)/N*100)
    
end

fprintf('\n')

for i = 1:N
   
    fprintf('Cp. %d of 1st eigenvector = %4.3f; Cp. %d of 2nd eigenvector = %4.3f\n',i,V(i,1),i,V(i,2))
        
end

fprintf('\n')

%%% Building principal components

E = [];
for i = 1:N
    
    E = [E; sum(V(:,i).*X)/sqrt(L(i))];
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Investment strategies %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

SR = []; % Empty array to store Sharpe Ratios

for t = 1:100:800
    
    %%% Full portfolio (with all principal components)
   
    X = R(:,t:t+99); % In-sample returns
        
    C = corr(X'); % In-sample correlation matrix
    
    I = C^-1; % Inverse of in-sample correlation matrix

    P = []; % Empty array to store in-sample store portfolio returns

    for i = 1:N
        w = sum(I(i,:))/sum(sum(I)); % Portfolio weight for i-th cryptocurrency
        P = [P; w*R(i,t+100:t+149)]; % Out-of sample weighted returns of i-th cryptocurrency
    end    
    
    P = sum(P); % Portfolio returns
    
    s1 = mean(P)/std(P); % Sharpe Ratio of portfolio with all principal components
    
    %%% Portfolio with 1st principal component removed
    
    [V,L] = eig(C); 
    [L,ind] = sort(diag(L),'descend');
    V = V(:,ind);
    
    E1 = sum(V(:,1).*X)/sqrt(L(1)); % 1st principal component of in-sample returns
    
    Y = []; % Empty array to store in-sample returns without 1st principal component
    
    for i = 1:N
        Y = [Y; X(i,:) - E1]; % Removing 1st principal component from in-sample returns of i-th cryptocurrency
    end    
    
    C = corr(Y'); % In-sample correlation matrix of returns without 1st principal component
    
    I = C^-1; % Inverse of in-sample correlation matrix of returns without 1st principal component

    P = []; % Empty array to store in-sample store portfolio returns without 1st principal component

    for i = 1:N
        w = sum(I(i,:))/sum(sum(I)); % Portfolio weight for i-th cryptocurrency
        P = [P; w*R(i,t+100:t+149)]; % Out-of sample weighted returns of i-th cryptocurrency
    end    
    
    P = sum(P); % Portfolio returns
    
    s2 = mean(P)/std(P); % Sharpe Ratio of portfolio without 1st principal component
    
    SR = [SR; s1 s2];
    
end

%%% Plotting Sharpe Ratios

figure(2)
plot(SR(:,1),'ro','MarkerSize',12,'MarkerFaceColor','red')
hold on
plot(SR(:,2),'bd','MarkerSize',12,'MarkerFaceColor','blue')
xlim([0 9])
ylim([-0.4 0.65])
xlabel('$\mathrm{Sample}$','Interpreter','Latex')
ylabel('$\mathrm{Sharpe \ Ratio}$','Interpreter','Latex')
legend({'$\mathrm{with \ 1st \ pc}$','$\mathrm{\mathrm{without \ 1st \ pc}}$'},'Interpreter','Latex','location','northwest')
set(gca,'FontSize',20)
