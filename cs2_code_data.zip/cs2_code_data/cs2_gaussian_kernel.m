clear all
close all

%%% The file loaded here is a 7x929 matrix where each row corresponds to
%%% 929 daily returns of a different cryptocurrency, ending in February
%%% 2018

%%% Row 1: Bitcoin
%%% Row 2: Dash
%%% Row 3: Ethereum
%%% Row 4: Litecoin
%%% Row 5: Monero
%%% Row 6: Nem
%%% Row 7: Ripple

b = load('cryptocurrency_prices.txt'); % Loading the file
b = b(1,:); % Here we select the cryptocurrency to analyze

r = log(b(2:end)./b(1:end-1)); % Log-returns

%%% Separating the data into training / validation / testing sets (one
%%% third of the data each)
pt = 0.33; % Fraction of data to use in training set
pv = 0.33; % Fraction of data to use in validation set
train_set = r(1:round(pt*length(r)));
N_T = length(train_set);
val_set = r(round(pt*length(r)+1:round((pt+pv)*length(r))));
test_set = r(round((pt+pv)*length(r))+1:end);

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Maximum-likelihood analysis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

h = logspace(-3,-1,100); % Logarithmic space for parameter h

L = []; % Empty vector to store all log-likelihood values

for i = 1:length(h)
    
    %%% Computing log-likelihood for Gaussian kernel evaluated on the
    %%% validation set (using the training set as fixed parameters
    
    p = gaussian_mix(val_set,train_set,h(i)); % Vector of Gaussian kernel values calculated in each point of validation set 
    
    aux = sum(log(p));
            
    L = [L; aux];
    
end

h_opt = h(find(L == max(L))); % Identifying optimal bandwidth value (i.e., argmax of log-likelihood)

fprintf('\n')
fprintf('Optimal kernel width: h = %4.3f\n',h_opt)
fprintf('\n')

subplot(2,2,1)

semilogx(h,L,'o-b','MarkerSize',8,'MarkerFaceColor','b') % Plotting the log-likelihood
set(gca,'FontSize',20)
title('Log-likelihood')
xlabel('$h$','Interpreter','LaTex')
ylabel('$\log \mathcal{L}$','Interpreter','LaTex')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Plot of optimal Gaussian kernel vs empirical distribution %%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Plot of optimal Gaussian kernel distribution's PDF vs histogram of
%%% training + validation set

subplot(2,2,2)

x = linspace(min(r)*1.05,max(r)*1.05,1000);
y = gaussian_mix(x,train_set,h_opt); % Values of kernel density for optimal bandwidth

plot(x,y,'r','LineWidth',2)
set(gca,'YScale','log')
hold on

NB = 20;
histogram([train_set val_set],NB,'Normalization','PDF','FaceColor','blue')

xlim([min(x) max(x)])
ylim([1e-2 100])
set(gca,'FontSize',20)
title('PDF')
xlabel('$r$','Interpreter','LaTex')
ylabel('$p(r)$','Interpreter','LaTex')

%%% Plot of optimal Gaussian kernel distribution's CCDF vs rank-frequency
%%% plot of training + validation set

subplot(2,2,3)

aux = sort([train_set val_set]);
y = 1:1:length(aux);
y = 1-y/(length(aux)+1);
plot(aux,y,'b','LineWidth',2)
hold on

x = linspace(min(r),max(r),500);
C = []; % Empty vector to store values of kernel's CCDF

for i = 1:length(x)
   
    tmp = sum(1-erf((x(i)-train_set)/sqrt(2*h_opt^2)))/(2*N_T);
    
    C = [C; tmp];
    
end

plot(x,C,'r','LineWidth',2)
set(gca,'FontSize',20)
title('CCDF')
xlabel('$r$','Interpreter','LaTex')
ylabel('$C(r)$','Interpreter','LaTex')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Q-Q plot of Gaussian kernel vs empirical distribution %%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

subplot(2,2,4)

%%% Here we introduce a two-variable function defined as the difference
%%% between the cumulative function of the kernel and a number. We will use
%%% it to solve numerically the inversion problem, since there is no close
%%% form expression for C^-1 in the case of a Gaussian. So, instead of
%%% solving direclty C^-1(u) = y, we will numerically search for a zero of
%%% the equation C(y)-u = 0. 

f = @(x,u) sum(1+erf((x-train_set)/sqrt(2*h_opt^2)))/(2*N_T) - u;

n_rand = 5000; % Number of random numbers to be generated

kernel_random_numbers = []; % Vector to store all random numbers to be generated

for i = 1:n_rand
   
    u = rand; % Random number drawn from uniform distribution over [0,1] 
    
    y = fzero(@(x) f(x,u),0); % Numerical solution of the equation C(y)-u = 0
    
    kernel_random_numbers = [kernel_random_numbers; y];
    
end

pvec = 0:1:100; % Vector of quantiles to be plotted
h = qqplot([train_set val_set],kernel_random_numbers,pvec);
set(h(1),'marker','o','markersize',8,'markeredgecolor','blue');
set(h(2),'linewidth',2,'color','red');
set(h(3),'linewidth',2,'color','red');

set(gca,'FontSize',20)
title('QQ Plot')
xlabel('$q_1$','Interpreter','LaTex')
ylabel('$q_2$','Interpreter','LaTex')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Two-sided Kolmogorov-Smirnov test between empirical data and random %%%
%%% numbers generated from the kernel density %%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

alpha = 0.05; % Significance level of the test

%%% Two-sided Komogorov-Smirnov test. b is a binary output (b = 1 means the
%%% null hypothesis of data coming from the same distribution is rejected,
%%% b = 0 means the null hypothesis cannot be rejected)

[b,p] = kstest2([train_set val_set],kernel_random_numbers,alpha); 

fprintf('Testing NH of compatible distributions on training + validation sets:\n')

if b == 1
   fprintf('NH rejected at %3.2f significance level (p = %3.2e)\n',alpha,p)
elseif b == 0
   fprintf('NH cannot be rejected at %3.2f significance level (p = %3.2e)\n',alpha,p)
end

fprintf('\n')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Testing against test set %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

figure(2)
subplot(1,3,1)

NB = 20;
histogram(test_set,NB,'Normalization','PDF','FaceColor','blue') % Histogram of test set data
hold on

x = linspace(min(r)*1.05,max(r)*1.05,1000);
y = gaussian_mix(x,train_set,h_opt); % Values of kernel density for optimal bandwidth

plot(x,y,'r','LineWidth',2)
set(gca,'YScale','log')

xlim([min(x) max(x)])
ylim([1e-2 100])
set(gca,'FontSize',20)
title('PDF')
xlabel('$r$','Interpreter','LaTex')
ylabel('$p(r)$','Interpreter','LaTex')

subplot(1,3,2)
test_set = sort(test_set);
y = 1:1:length(test_set);
y = 1-y/(length(test_set)+1);
plot(test_set,y,'b','LineWidth',2)
hold on

x = linspace(min(test_set),max(test_set),500);

plot(x,C,'r','LineWidth',2) % Replotting Gaussian kernel CCDF
set(gca,'FontSize',20)
title('CCDF')
xlabel('$r$','Interpreter','LaTex')
ylabel('$C(r)$','Interpreter','LaTex')

subplot(1,3,3)

%%% New QQ plot with previously generated random numbers from kernel
%%% density vs quantiles of data in the test set

h = qqplot(test_set,kernel_random_numbers,pvec);
set(h(1),'marker','o','markersize',8,'markeredgecolor','blue');
set(h(2),'linewidth',2,'color','red');
set(h(3),'linewidth',2,'color','red');

set(gca,'FontSize',20)
title('QQ Plot')
xlabel('$q_1$','Interpreter','LaTex')
ylabel('$q_2$','Interpreter','LaTex')

%%% Two-sided Kolmogorov-Smirnov test between previously generated random
%%% numbers from kernel density and test set data

alpha = 0.05;
[b,p] = kstest2(test_set,kernel_random_numbers,alpha);

fprintf('Testing NH of compatible distributions on test set:\n')

if b == 1
   fprintf('NH rejected at %3.2f significance level (p = %3.2e)\n',alpha,p)
elseif b == 0
   fprintf('NH cannot be rejected at %3.2f significance level (p = %3.2e)\n',alpha,p)
end

fprintf('\n')
