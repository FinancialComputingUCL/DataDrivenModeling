%%% This is a simple code to familiarize with sums of Gaussian
%%% distributions. The following code shows a plot of a number of different
%%% Gaussian distributions centred around different means and the
%%% distribution resulting from their normalized sum

clear all
close all

mu = [-2 -1 0.5 2]; % Vector of means for individual Gaussian distributions
s = 0.6; % Standard deviation of all Gaussian distributions

N = length(mu); % Number of Gaussian distributions to plot

for i = 1:N
   
    % Support of i-th Gaussian distribution (mean plus/minus 5 standard
    % deviations)
    x = linspace(mu(i)-5*s,mu(i)+5*s,100); 
    
    y = exp(-(x-mu(i)).^2/(2*s^2))/sqrt(2*pi*s^2);
        
    plot(x,y,'r--','LineWidth',1.5)
    hold on
    
end

% Support of sum of Gaussians defines as interval between lowest mean minus
% 5 std. deviations and highest mean plus 5 std. deviations
x = linspace(min(mu)-5*s,max(mu)+5*s,500);
y = gaussian_mix(x,mu,s); % Calling function to compute sum of Gaussians in all values of x

plot(x,y,'b-','LineWidth',2.5)
set(gca,'FontSize',20)
