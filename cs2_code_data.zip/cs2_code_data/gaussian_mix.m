%%% This function evaluates a normalized sum of N Gaussian functions with
%%% means specified by the input vector mu and standard deviation equal to
%%% s. The function is computed in each point of the input vector x.

function G = gaussian_mix(x,mu,s)

    N = length(mu);
    
    G = 0;
    
    for i = 1:N
       
        G = G + exp(-(x-mu(i)).^2/(2*s^2))/sqrt(2*pi*s^2);
        
    end
    
    G = G/N;

end