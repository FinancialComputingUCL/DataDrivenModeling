clear all
close all

%%% The file loaded here is a 7x929 matrix where each row corresponds to
%%% 929 daily returns of a different cryptocurrency, ending in February
%%% 2018

%%% Row 1: Bitcoin
%%% Row 2: Dash
%%% Row 3: Ethereum
%%% Row 4: Litecoin
%%% Row 5: Monero
%%% Row 6: Nem
%%% Row 7: Ripple

b = load('cryptocurrency_prices.txt'); % Loading the file
b = b(1,:); % Here we select the cryptocurrency to analyze

r = log(b(2:end)./b(1:end-1)); % Log-returns

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Aggregation of returns %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

tau = 7; % Number of days for aggregation of returns 

flag = 0; % Flag variable (set to 1 to aggregate returns over longer time scales)

if flag == 1
    
    aux = [];
   
    for t = 0:tau:length(r)-tau
       
        aux = [aux; sum(r(t+1:t+tau))];
        
    end
    
    r = aux;
    
end

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% First four moments %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

% Compute and print the values of the first four moments

N = length(r); % Number of log-returns

m = sum(r)/N; % Compute mean and store value in variable
fprintf('\n')
fprintf('Mean = %4.3f\n',m)

s = sqrt(sum((r-m).^2)/N); % Compute std. deviation and store value in variable
fprintf('Std. deviation = %4.3f\n',s)

fprintf('Skewness = %4.3f\n',sum((r-m).^3)/(N*s^3))

fprintf('Excess kurtosis = %4.3f\n',sum((r-m).^4)/(N*s^4)-3)

fprintf('\n')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Plot of empirical PDF vs Gaussian %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x = linspace(min(r),max(r),100); % Point grid between min and max return
g = exp(-(x-m).^2/(2*s^2))/sqrt(2*pi*s^2); % Gaussian PDF values computed on point grid

NB = 30; % Number of bins for histogram of returns

subplot(1,2,1)

histogram(r,NB,'Normalization','PDF')
hold on
plot(x,g,'r','LineWidth',2)
set(gca,'YScale','log')
xlim([-0.4 0.4])
ylim([0.03 15])
xlabel('$r$','Interpreter','LaTex')
ylabel('$p(r)$','Interpreter','LaTex')
set(gca,'TickLabelInterpreter','LaTex')
set(gca,'FontSize',20)
title('PDF')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Plot of empirical CCDF vs Gaussian %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

x = sort(r); % Returns sorted in ascending order
y = 1:1:length(r); 
y = 1 - y/(length(r)+1); % Calculating CCDF as rank-frequency plot
 
c = 0.5*(1 - erf((x-m)/(s*sqrt(2)))); % Gaussian CCDF
 
subplot(1,2,2)
semilogy(x,y,'b','LineWidth',2)
hold on
semilogy(x,c,'r','LineWidth',2)
ylim([1e-4 1])
xlabel('$r$','Interpreter','LaTex')
ylabel('$C(r)$','Interpreter','LaTex')
set(gca,'TickLabelInterpreter','LaTex')
set(gca,'FontSize',20)
title('CCDF')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Fitting right & left tail via Maximum Likelihood %%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

p = 0.1; % Defining tails as top p% of returns (both positive and negative)

figure(2)

%%% Right tail %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

r = sort(r); % Sorting returns
r_right = r(round((1-p)*length(r)):end); % Selecting top p% of returns

N = length(r_right); % Number of returns selected as right tail
alpha_right = N/sum(log(r_right/min(r_right))); % Maximum-likelihood estimate for right tail exponent

fprintf('Right tail exponent: %4.3f\n',alpha_right)

x_right = linspace(min(r_right),max(r_right),100); % Grid of points between min and max values in right tail
y_right = alpha_right*(x_right/min(r_right)).^(-alpha_right-1)/min(r_right); % Values of power law distribution on grid of points

[b_right,a_right] = histnorm(r_right,20);

subplot(1,2,1)
loglog(a_right,b_right,'ob','MarkerSize',8,'MarkerFaceColor','b')
hold on
loglog(x_right,y_right,'r','LineWidth',2)
xlabel('$r$','Interpreter','LaTex')
ylabel('$p(r)$','Interpreter','LaTex')
set(gca,'TickLabelInterpreter','LaTex')
set(gca,'FontSize',20)
title('Right tail')

%%% Left tail %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

r_left = r(1:round(p*length(r))); % Selecting bottom p% of returns
r_left = abs(r_left); % Converting negative returns to positive numbers

N = length(r_left); % Number of returns selected as left tail
alpha_left = N/sum(log(r_left/min(r_left))); % Maximum-likelihood estimate for left tail exponent

fprintf('Left tail exponent: %4.3f\n',alpha_left)

x_left = linspace(min(r_left),max(r_left),100);
y_left = alpha_left*(x_left/min(r_left)).^(-alpha_left-1)/min(r_left); % Power law distribution

[b_left,a_left] = histnorm(r_left,20);

subplot(1,2,2)
loglog(a_left,b_left,'ob','MarkerSize',8,'MarkerFaceColor','b')
hold on
loglog(x_left,y_left,'r','LineWidth',2)
xlabel('$r$','Interpreter','LaTex')
ylabel('$p(r)$','Interpreter','LaTex')
set(gca,'TickLabelInterpreter','LaTex')
set(gca,'FontSize',20)
title('Left tail')

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Bootstrap analysis %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

bts = 0.8; % Fraction of data to be retained in each bootstrap sample
Nbts = 500; % Number of bootstrap samples
alpha = 0.9; % Significance level

%%% Right tail with bootstrap %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

alpha_right_bts = []; % Vector to collect bootstrap estimates for right tail exponent

for i = 1:Nbts
   
    r_bts = r(randperm(length(r))); % Random permutation of returns
    r_bts = r_bts(1:round(bts*length(r_bts))); % Bootstrapping bts% of returns 
    r_bts = sort(r_bts); % Sorting bootstrapped returns
    r_right_bts = r_bts(round((1-p)*length(r_bts)):end); % Selecting top p% of returns
    
    N_bts = length(r_right_bts); % Number of bootstrapped returns
    
    alpha_right_bts = [alpha_right_bts; N_bts/sum(log(r_right_bts/min(r_right_bts)))];

end

alpha_right_bts = sort(alpha_right_bts); % Sorting bootstrap estimates for right tail exponent

fprintf('Right tail interval at %3.2f CL: [%4.3f; %4.3f] \n',alpha,alpha_right_bts(round(0.5*(1-alpha)*Nbts)),alpha_right_bts(round(0.5*(1+alpha)*Nbts)))
fprintf('\n')

%%% Left tail with bootstrap %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

alpha_left_bts = []; % Vector to collect bootstrap estimates for left tail exponent

for i = 1:Nbts
   
    r_bts = r(randperm(length(r))); % Random permutation of returns
    r_bts = r_bts(1:round(bts*length(r_bts))); % Bootstrapping bts% of returns 
    r_bts = sort(r_bts); % Sorting bootstrapped returns
    r_left_bts = r_bts(1:round(p*length(r_bts))); % Selecting bottom p% of returns
    r_left_bts = abs(r_left_bts); % Converting returns to positive
    
    N_bts = length(r_left_bts); % Number of bootstrapped returns
    
    alpha_left_bts = [alpha_left_bts; N_bts/sum(log(r_left_bts/min(r_left_bts)))];

end

alpha_left_bts = sort(alpha_left_bts); % Sorting bootstrap estimates for right tail exponent

fprintf('Left tail interval at %3.2f CL: [%4.3f; %4.3f] \n',alpha,alpha_left_bts(round(0.5*(1-alpha)*Nbts)),alpha_left_bts(round(0.5*(1+alpha)*Nbts)))
fprintf('\n')

figure(3)
boxplot([alpha_right_bts alpha_left_bts])
xticks([1 2])
xticklabels({'$\alpha_R$','$\alpha_L$'})
set(gca,'FontSize',20)
set(gca,'TickLabelInterpreter','LaTex')
title('Boostrap tail exponent values')
