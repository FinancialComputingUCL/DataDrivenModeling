
function L = tail_body_likelihood(r,params,pen)

    l = params(1); alpha = params(2); xmin = params(3);
    
    C = 2 - exp(-l*xmin); % Normalization constant
    
    L = 0; % Initializing likelihood
   
    %%% Finding returns lower than xmin
    r = sort(r);
    f = length(find(r < xmin));
    
    %%% Computing log-likelihood values for the body of the distribution 
    for i = 1:f
        L = L - log(C) + log(l) - l*r(i);
    end
    
    %%% Computing log-likelihood values for the tail of the distribution     
    for i = f+1:length(r)
        L = L - log(C) + log(alpha/xmin) - (alpha+1)*log(r(i)/xmin);
    end
    
    %%% Computing values of body and tail distributions at xmin
    Fbody = l*exp(-l*xmin)/C;
    Ftail = alpha/(C*xmin);
    
    %%% Adding penalty term to enforce continuity
    L = L - pen*(Fbody-Ftail)^2;
    
    %%% Changing sign to log-likelihood (fminsearch algorithm searches for minima)
    L = - L;
    
end
