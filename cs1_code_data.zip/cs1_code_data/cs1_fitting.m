clear all
close all

%%% The file loaded here is a 7x929 matrix where each row corresponds to
%%% 929 daily returns of a different cryptocurrency, ending in February
%%% 2018

%%% Row 1: Bitcoin
%%% Row 2: Dash
%%% Row 3: Ethereum
%%% Row 4: Litecoin
%%% Row 5: Monero
%%% Row 6: Nem
%%% Row 7: Ripple

b = load('cryptocurrency_prices.txt'); % Loading the file
b = b(1,:); % Here we select the cryptocurrency to analyze

r = log(b(2:end)./b(1:end-1)); % Log-returns
r = abs(r(find(r > 0))); % Selecting only positive/negative returns (to study right/left tail)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Calibration of body + tail of distribution %%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

%%% Here we calibrate via maximum likelihood an exponential distribution 
%%% for the body and a power law distribution for the tail of the returns'
%%% empirical distribution

penalty = 10; % Penalty parameter (to enforce continuity in xmin)

%%% Initial values of the distribution's parameter to be passed as input to
%%% the ML optimization problem
lambda = 10; alpha = 2; xmin = 0.05; 
start = [lambda alpha xmin];

%%% Maximum likelihood optimization %%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

[par,val,exitflag,output] = fminsearch(@(params) tail_body_likelihood(r,params,penalty),start,...
                                    optimset('TolX',1e-12,'MaxIter',1000,'MaxFunEvals',5000));
lambda = par(1); alpha = par(2); xmin = par(3);

fprintf('\n')
fprintf('Parameters that maximize likelihood:\n')
fprintf('lambda = %4.3f; alpha = %4.3f; xmin = %4.3f\n\n',lambda,alpha,xmin)

%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%
%%% Plotting empirical vs calibrated distribution %%%%%%%%%%%%%%%%%%%%%%%%%
%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%%

C = 2 - exp(-lambda*xmin); % Normalization constant

%%% Plots of PDF and complementary cumulative function

NB = 40; % Number of bins

subplot(1,2,1)
h = histogram(r,NB,'Normalization','pdf');
plot(h.BinEdges(1:NB),h.Values,'ob','MarkerSize',8,'MarkerFaceColor','b')
hold on
x = linspace(0,xmin,1000);
plot(x,lambda*exp(-lambda*x)/C,'-r','LineWidth',1.5)
hold on
x = linspace(xmin,max(r),1000);
plot(x,alpha*(x/xmin).^(-alpha-1)/(C*xmin),'-r','LineWidth',1.5)
hold on
xline(xmin,'--k','LineWidth',1);
xlim([min(r) max(r)])
xlabel('$r$','Interpreter','LaTex')
ylabel('$p(r)$','Interpreter','LaTex')
set(gca,'TickLabelInterpreter','LaTex')
set(gca,'FontSize',20)
set(gca,'XScale','log')
set(gca,'YScale','log')

subplot(1,2,2)
r = sort(r); % Returns sorted in ascending order
y = 1:1:length(r); 
y = 1-y/(length(r)+1); % Calculating CCDF as rank-frequency plot
plot(r,y,'b','LineWidth',1.5)
hold on
x = linspace(min(r),xmin,1000);
plot(x,1-(1-exp(-lambda*x))/C,'-r','LineWidth',1.5)
hold on
x = linspace(xmin,max(r)*10,1000);
plot(x,1-(1-exp(-lambda*xmin)+1-(xmin./x).^alpha)/C,'-r','LineWidth',1.5)
hold on
xline(xmin,'--k','LineWidth',1);
xlim([min(r) max(r)])
xlabel('$r$','Interpreter','LaTex')
ylabel('$C(r)$','Interpreter','LaTex')
set(gca,'TickLabelInterpreter','LaTex')
set(gca,'FontSize',20)
set(gca,'XScale','log')
